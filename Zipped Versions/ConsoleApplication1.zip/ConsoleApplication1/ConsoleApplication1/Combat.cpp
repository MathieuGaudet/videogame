#include "pch.h"
#include "Combat.h"


void initiateCombat(){

	
}