#pragma once

void initiateCombat();
